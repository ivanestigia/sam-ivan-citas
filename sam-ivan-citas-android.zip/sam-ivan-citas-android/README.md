# Sam + Ivan — Android APK wrapper

Proyecto Android nativo para que la app aparezca correctamente en Oasis Launcher y otros launchers.

## Qué hace

- Crea una app Android real con `MAIN` + `LAUNCHER`.
- Nombre visible: `Sam + Ivan`.
- Package ID: `com.estratoscorp.samivan.citas`.
- Carga la app web actual:
  `https://citas-ivan-sam.netlify.app/?source=apk`
- Mantiene sesión vía WebView storage/cookies.
- Soporta selector de archivos para subir fotos.

## Opción recomendada sin Android Studio: GitHub Actions

1. Sube esta carpeta a un repo de GitHub.
2. Entra al repo → pestaña `Actions`.
3. Ejecuta workflow `Build Sam Ivan APK`.
4. Descarga el artifact `sam-ivan-debug-apk`.
5. Instala `app-debug.apk` en Android.

Workflow incluido:

```txt
.github/workflows/build-apk.yml
```

## Opción con Android Studio

Solo si quieres compilar local:

1. Abrir esta carpeta en Android Studio:
   `sam-ivan-citas-android`
2. Esperar Gradle Sync.
3. Menú: `Build > Generate Signed Bundle / APK...`
4. Elegir `APK`.
5. Crear keystore nuevo y guardarlo fuera del repo.
6. Build variant: `release`.
7. Instalar el APK en el celular.

## Build debug local

Si tienes Gradle/Android SDK configurado:

```bash
gradle :app:assembleDebug
```

APK esperado:

```txt
app/build/outputs/apk/debug/app-debug.apk
```

## Nota

Esto es un wrapper WebView, no PWA. La ventaja: Android lo trata como app real y Oasis Launcher debe enlistarla.
